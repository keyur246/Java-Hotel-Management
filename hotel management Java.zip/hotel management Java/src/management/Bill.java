package management;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

public class Bill extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JLabel lblNewLabel_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bill frame = new Bill();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bill() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 702, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Room no");
		lblNewLabel.setBounds(39, 55, 112, 34);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(163, 55, 121, 34);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Coustumer Name");
		lblNewLabel_1.setBounds(39, 115, 112, 34);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(149, 118, 266, 31);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Checkin Date");
		lblNewLabel_2.setBounds(36, 184, 96, 34);
		contentPane.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(149, 187, 266, 31);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Checkout Date");
		lblNewLabel_3.setBounds(106, 252, 93, 24);
		contentPane.add(lblNewLabel_3);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(211, 252, 133, 24);
		contentPane.add(dateChooser);
		
		JLabel lblNewLabel_4 = new JLabel("Checkout Time");
		lblNewLabel_4.setBounds(384, 256, 112, 16);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Restaurant bill");
		lblNewLabel_5.setBounds(397, 318, 121, 34);
		contentPane.add(lblNewLabel_5);
		
		textField_3 = new JTextField();
		textField_3.setBounds(517, 321, 155, 28);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_3.setVisible(false);
		lblNewLabel_5.setVisible(false);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Add Restaurant Bill");
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField_3.setVisible(true);
				lblNewLabel_5.setVisible(true);
			}
		});
		chckbxNewCheckBox.setBounds(240, 298, 149, 24);
		contentPane.add(chckbxNewCheckBox);
		
		JLabel lblNewLabel_6 = new JLabel("Adv, Amount");
		lblNewLabel_6.setBounds(39, 348, 86, 27);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Pay Amount");
		lblNewLabel_7.setBounds(39, 388, 77, 34);
		contentPane.add(lblNewLabel_7);
		
		textField_4 = new JTextField();
		textField_4.setBounds(141, 355, 149, 24);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(149, 399, 153, 24);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Pay");
		btnNewButton.setBounds(363, 416, 133, 59);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setBounds(482, 256, 143, 34);
		contentPane.add(lblNewLabel_8);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.setBounds(445, 60, 97, 25);
		contentPane.add(btnNewButton_1 );

	}
}

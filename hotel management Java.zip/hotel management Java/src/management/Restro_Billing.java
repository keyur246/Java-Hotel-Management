package management;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;

public class Restro_Billing extends JFrame {

	private JPanel contentPane;
	private JRadioButton r1,r2,r3;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Restro_Billing frame = new Restro_Billing();
				frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the 
	 */
	public Restro_Billing() {
		setUndecorated(true);
		
		getContentPane().setBackground(new Color(128, 0, 0));
		setBounds(100, 100, 700, 700);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Subtotal:");
		lblNewLabel_1.setForeground(new Color(255, 215, 0));
		lblNewLabel_1.setFont(new Font("Sitka Small", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(54, 505, 103, 31);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Tax:");
		lblNewLabel_2.setForeground(new Color(255, 215, 0));
		lblNewLabel_2.setFont(new Font("Sitka Small", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(75, 535, 46, 44);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Total:");
		lblNewLabel_3.setForeground(new Color(255, 215, 0));
		lblNewLabel_3.setFont(new Font("Sitka Small", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(73, 463, 82, 26);
		getContentPane().add(lblNewLabel_3);
		
		JLabel l1 = new JLabel("Rs.0");
		l1.setForeground(new Color(0, 0, 0));
		l1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		l1.setBounds(183, 507, 93, 21);
		getContentPane().add(l1);
		
		JLabel lblNewLabel_5 = new JLabel("Rs.35");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_5.setBounds(184, 545, 64, 23);
		getContentPane().add(lblNewLabel_5);
		
		JLabel l2 = new JLabel("Rs.0");
		l2.setForeground(new Color(0, 0, 0));
		l2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		l2.setBounds(184, 460, 82, 26);
		getContentPane().add(l2);
		
		JButton btnPayment = new JButton("PAYMENT");
		btnPayment.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnPayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				
				Pay.main(null);
			}
		});
		btnPayment.setBackground(new Color(245, 222, 179));
		btnPayment.setBounds(385, 484, 160, 44);
		getContentPane().add(btnPayment);
		
		JRadioButton r1 = new JRadioButton("BREAKFAST BUFFET             Rs.500");
		r1.setBackground(new Color(255, 215, 0));
		r1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		           if(r1.isSelected())
		           {
		        	   r2.setSelected(false);
		        	   r3.setSelected(false);
		        	   
		           }
					
					l1.setText("Rs."+500);
					l2.setText("Rs."+535);
					
				
			}
		});
		r1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		r1.setBounds(29, 195, 370, 44);
		getContentPane().add(r1);
		
		r2 = new JRadioButton("LUNCH BUFFET                      Rs.800");
		r2.setBackground(new Color(255, 215, 0));
		r2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(r2.isSelected())
		           {
		        	   r1.setSelected(false);
		        	   r3.setSelected(false);
		        	   
		           }
				
				l1.setText("Rs."+800);
				l2.setText("Rs."+835);
			}
		});
		r2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		r2.setBounds(29, 283, 370, 44);
		getContentPane().add(r2);
		
		r3 = new JRadioButton("DINNER BUFFET                     Rs.1000");
		r3.setBackground(new Color(255, 215, 0));
		r3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//dispose();
				if(r3.isSelected())
		           {
		        	   r1.setSelected(false);
		        	   r2.setSelected(false);
		        	   
		           }
				
				l1.setText("Rs."+1000);
				l2.setText("Rs."+1035);
			}
		});
		r3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		r3.setBounds(29, 365, 370, 44);
		getContentPane().add(r3);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				Main_Page1.main(null);
				dispose();
				
			}
		});
		lblNewLabel_4.setIcon(new ImageIcon(Restro_Billing.class.getResource("/images/home-black-building-symbol (1).png")));
		lblNewLabel_4.setBounds(609, 0, 69, 65);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon(Restro_Billing.class.getResource("/images/h2.png")));
		lblNewLabel_7.setBounds(0, 0, 678, 154);
		getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Restro_Billing.class.getResource("/images/n1.png")));
		lblNewLabel.setBounds(447, 226, 196, 165);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				User.main(null);
				dispose();
				
			}
		});
		lblNewLabel_6.setIcon(new ImageIcon(Restro_Billing.class.getResource("/images/back.png")));
		lblNewLabel_6.setBounds(15, 567, 69, 77);
		getContentPane().add(lblNewLabel_6);
		
		JLabel label = new JLabel("New label");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				dispose();
				
			}
		});
		label.setIcon(new ImageIcon(Restro_Billing.class.getResource("/images/logout.png")));
		label.setBounds(609, 567, 69, 77);
		getContentPane().add(label);
	}

}

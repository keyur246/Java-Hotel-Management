package management;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.util.Calendar;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.Connection;
import java.awt.Color;

public class Cust_Info extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_3;
	private JTextField textField_5;
	static String rno="";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cust_Info frame = new Cust_Info();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cust_Info() {
		
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(100, 100, 585, 799);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.scrollbar);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("NAME*   :   ");
		lblName.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblName.setBounds(50, 135, 141, 37);
		getContentPane().add(lblName);
		
		textField = new JTextField();
		textField.setBounds(173, 139, 363, 37);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNationality = new JLabel("NATIONALITY*    :  ");
		lblNationality.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNationality.setBounds(50, 203, 231, 29);
		getContentPane().add(lblNationality);
		
		textField_1 = new JTextField();
		textField_1.setBounds(267, 203, 269, 37);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblPermanentAddress = new JLabel("PERMANENT ADDRESS * : ");
		lblPermanentAddress.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblPermanentAddress.setBounds(50, 251, 353, 29);
		getContentPane().add(lblPermanentAddress);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textField_2.setBounds(50, 291, 477, 90);
		getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblPhoneNumber = new JLabel("PHONE NUMBER*  :  ");
		lblPhoneNumber.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPhoneNumber.setBounds(50, 412, 208, 29);
		getContentPane().add(lblPhoneNumber);
		
		textField_4 = new JTextField();
		textField_4.setBounds(248, 411, 289, 37);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JButton button = new JButton("<---   BACK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			Room.main(null);
			}
		});
		button.setFont(new Font("Times New Roman", Font.BOLD, 20));
		button.setBounds(27, 712, 161, 37);
		getContentPane().add(button);
		
		JButton btnNext = new JButton("NEXT   --->");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(textField.getText().compareTo("")!=0 && textField_1.getText().compareTo("")!=0 && textField_2.getText().compareTo("")!=0 && textField_3.getText().compareTo("")!=0 && textField_4.getText().compareTo("")!=0 && textField_5.getText().compareTo("")!=0)
				{
					String name=(textField.getText());
					String nationality=(textField_1.getText());
					String address=(textField_2.getText());
					int adults=Integer.parseInt(textField_3.getText());
					long phone_number=Long.parseLong(textField_4.getText());
					int kids=Integer.parseInt(textField_3.getText());
					//int room_number=Integer.parseInt(textField_6.getText());
					if(textField_4.getText().length()!=10)
					 {
						 JOptionPane.showMessageDialog(null,"***PLEASE INPUT THE CORRECT PHONE NUMBER***");
					 }
					 
					 /*else if(textField_3.getText().length()!=12)
					 {
						 JOptionPane.showMessageDialog(null,"***PLEASE INPUT THE CORRECT AADHAR NUMBER***");
					 }
					
					 else if(textField_5.getText().length()!=12)
					 {
						 JOptionPane.showMessageDialog(null,"***PLEASE INPUT THE CORRECT AADHAR NUMBER***");
					 }
					*/
					 else
					 {
						 dispose();
						 String dbName="employeedb";
						 String driverName="com.mysql.jdbc.Driver";
						 String url="jdbc:mysql://localhost:3306/";
						 try{
							 Class.forName(driverName);
							 String query="update customer set Name=?,Nationality=?,address=?,adults=?,phone_no=?,kids=? where roomno=?";
							 Connection con=(Connection) DriverManager.getConnection(url+dbName,"root","root");
							 java.sql.PreparedStatement st=con.prepareStatement(query);
			                 st.setString(1, name);
			                 st.setString(2, nationality); 
			                 st.setString(3, address);
			                 st.setInt(4, adults);
			                 st.setLong(5, phone_number); 
			                 st.setInt(6, kids);
			                st.setString(7, rno);
			                 
			                 st.execute();   

								JOptionPane.showMessageDialog(null,"*****Room is booked*****\n");
								
			                
			                 
						 }
						 
						 catch(Exception e)
						 {
							 e.printStackTrace();
						 }
						
						
					
					 }
						 
					 }
					
				
				
				else
				{
					JOptionPane.showMessageDialog(null,"All data has not been entered");
				}
			}
				
		});
		btnNext.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNext.setBounds(357, 712, 154, 37);
		getContentPane().add(btnNext);
		
		JLabel lblNumberOfAdults = new JLabel("NUMBER OF ADULTS *    :    ");
		lblNumberOfAdults.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNumberOfAdults.setBounds(50, 467, 264, 37);
		contentPane.add(lblNumberOfAdults);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textField_3.setBounds(324, 467, 87, 37);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNumberOfKids = new JLabel("NUMBER OF KIDS *            :  ");
		lblNumberOfKids.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNumberOfKids.setBounds(50, 525, 264, 29);
		contentPane.add(lblNumberOfKids);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textField_5.setBounds(317, 521, 87, 37);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.BOLD, 20));
		spinner.setModel(new SpinnerDateModel(new Date(1533321000000L), new Date(1533321000000L), new Date(1564857000000L), Calendar.DAY_OF_YEAR));
		spinner.setBounds(187, 634, 171, 48);
		contentPane.add(spinner);
		
		JLabel lblCheckInDate = new JLabel("CHECK IN DATE  ");
		lblCheckInDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblCheckInDate.setBounds(174, 594, 196, 29);
		contentPane.add(lblCheckInDate);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Asmita\\Desktop\\project images\\doorknob (1).png"));
		label.setBounds(-13, 0, 117, 134);
		contentPane.add(label);
		
		JLabel lblRoomBooking = new JLabel("           ROOM BOOKING");
		lblRoomBooking.setBackground(new Color(153, 204, 255));
		lblRoomBooking.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		lblRoomBooking.setBounds(82, 48, 477, 78);
		lblRoomBooking.setOpaque(true);
		contentPane.add(lblRoomBooking);


	}
}

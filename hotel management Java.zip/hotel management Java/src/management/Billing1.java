package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.SystemColor;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.text.JTextComponent;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class Billing1 extends JFrame {

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JCheckBox c1;
	private JLabel l1,l2,l3,l4;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Billing1 window = new Billing1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Billing1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setUndecorated(true);
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(128, 0, 0));
		frame.getContentPane().setForeground(SystemColor.inactiveCaption);
		frame.setBounds(100, 100, 550, 900);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Room No    :");
		lblNewLabel_1.setForeground(new Color(255, 215, 0));
		lblNewLabel_1.setBounds(44, 197, 126, 28);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Room Total  :");
		lblNewLabel_2.setForeground(new Color(255, 215, 0));
		lblNewLabel_2.setBounds(44, 256, 143, 30);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("Tax:");
		lblNewLabel_4.setForeground(new Color(255, 215, 0));
		lblNewLabel_4.setBounds(95, 401, 46, 23);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Discount:");
		lblNewLabel_5.setForeground(new Color(255, 215, 0));
		lblNewLabel_5.setBounds(92, 440, 95, 23);
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Subtotal:");
		lblNewLabel_6.setForeground(new Color(255, 215, 0));
		lblNewLabel_6.setBounds(95, 489, 92, 27);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Paid       :");
		lblNewLabel_7.setForeground(new Color(255, 215, 0));
		lblNewLabel_7.setBounds(95, 532, 92, 23);
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Total      :");
		lblNewLabel_8.setForeground(new Color(255, 215, 0));
		lblNewLabel_8.setBounds(92, 581, 106, 27);
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 22));
		frame.getContentPane().add(lblNewLabel_8);
		
		t1 = new JTextField();
		t1.setBounds(228, 258, 117, 30);
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		 c1 = new JCheckBox("Food");
		 c1.setBackground(new Color(255, 215, 0));
		 c1.setBounds(44, 313, 85, 37);
		c1.setFont(new Font("Times New Roman", Font.BOLD, 21));
		frame.getContentPane().add(c1);
		
		l1 = new JLabel("Rs.300");
		l1.setBounds(228, 401, 78, 23);
		l1.setForeground(new Color(0, 0, 0));
		l1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		frame.getContentPane().add(l1);
		
		t2 = new JTextField();
		t2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		t2.setBounds(228, 440, 117, 24);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		 l2 = new JLabel("Rs.0");
		 l2.setBounds(234, 491, 111, 21);
		 l2.setFont(new Font("Tahoma", Font.PLAIN, 22));
		 l2.setForeground(new Color(0, 102, 204));
		frame.getContentPane().add(l2);
		
		 l3 = new JLabel("Rs.1000");
		 l3.setBounds(228, 531, 95, 23);
		l3.setFont(new Font("Tahoma", Font.PLAIN, 22));
		l3.setForeground(new Color(0, 0, 0));
		frame.getContentPane().add(l3);
		
		 l4 = new JLabel("Rs.0");
		 l4.setBounds(237, 580, 108, 28);
		 l4.setForeground(new Color(0, 102, 204));
		l4.setFont(new Font("Tahoma", Font.PLAIN, 22));
		frame.getContentPane().add(l4);
		
		JLabel lblrs = new JLabel("(Rs.500 )");
		lblrs.setBounds(171, 321, 95, 29);
		lblrs.setForeground(new Color(0, 102, 204));
		lblrs.setFont(new Font("Tahoma", Font.PLAIN, 20));
		frame.getContentPane().add(lblrs);
		
		textField = new JTextField();
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
			}
		});
		textField.setBounds(226, 200, 119, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Billing1.class.getResource("/images/bs1.png")));
		label.setBounds(31, 16, 470, 135);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				if(textField.getText().compareTo("")!=0 && t1.getText().compareTo("")!=0 && t2.getText().compareTo("")!=0)
				{
					int a=Integer.parseInt(t1.getText());
					int b=Integer.parseInt(t2.getText());
					
					if(c1.isSelected())
					{
						int c=a+500+300-b;
						l2.setText("Rs. "+c);
						
						int d=c-1000;
						l4.setText("Rs. "+d);
						
						
					}
					else
					{
						int c=a+300-b;
						l2.setText("Rs. "+c);
						
						int d=c-1000;
						l4.setText("Rs. "+d);
						
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null,"*** Please enter all the values ***");	
				}
				
			
			}
		});
		lblNewLabel.setIcon(new ImageIcon(Billing1.class.getResource("/images/total1.png")));
		lblNewLabel.setBounds(44, 647, 155, 50);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			    try
						{
							Class.forName("com.mysql.jdbc.Driver");
							Connection c=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedb", "root", "root");	
					
								PreparedStatement p1=(PreparedStatement)c.prepareStatement("DELETE FROM customer WHERE roomno= ?");
								p1.setString(1,textField.getText());
						
								p1.executeUpdate();		
							
					     }
					catch(Exception e1)
					{
						e1.printStackTrace();
					}
					Pay.main(null);
				
					frame.dispose();
			}
		});
		lblNewLabel_3.setIcon(new ImageIcon(Billing1.class.getResource("/images/mp1.png")));
		lblNewLabel_3.setBounds(274, 608, 212, 120);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_9 = new JLabel("New label");
		lblNewLabel_9.addMouseMotionListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {
				
				Lodging1.main(null);
				dispose();
			}
		});
		lblNewLabel_9.setIcon(new ImageIcon(Billing1.class.getResource("/images/back.png")));
		lblNewLabel_9.setBounds(15, 757, 69, 71);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("New label");
		lblNewLabel_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				dispose();
			}
		});
		lblNewLabel_10.setIcon(new ImageIcon(Billing1.class.getResource("/images/logout.png")));
		lblNewLabel_10.setBounds(459, 758, 69, 68);
		frame.getContentPane().add(lblNewLabel_10);
		
		

	}
}

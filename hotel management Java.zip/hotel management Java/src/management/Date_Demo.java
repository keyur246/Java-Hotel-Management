package management;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.Connection;
import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;

public class Date_Demo extends JFrame {

	private JPanel contentPane;
	private JDateChooser dateChooser;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Date_Demo frame = new Date_Demo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the 
	 */
	public Date_Demo() {
		
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(183, 58, 100, 22);
		getContentPane().add(dateChooser);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String dbName="mydb";
				 String driverName="com.mysql.jdbc.Driver";
				 String url="jdbc:mysql://localhost:3306/";
				 try{
					 Class.forName(driverName);
					 String query="insert into scalr values(?)";
					 Connection con=(Connection) DriverManager.getConnection(url+dbName,"root","root");
					 java.sql.PreparedStatement st=con.prepareStatement(query);
			        
			        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
			        String date=sdf.format(dateChooser.getDate());
			        st.setString(1, date);
			     
			       
			        
			        st.execute();   

					
						
			       
			        
				 }
				 
				 catch(Exception e)
				 {
					 e.printStackTrace();
				 }
			}
			
		});
		btnNewButton.setBounds(186, 140, 97, 25);
		getContentPane().add(btnNewButton);
	}

}
